package com.API.API_REST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
